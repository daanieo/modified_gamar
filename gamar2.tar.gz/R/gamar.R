#' gamar : An R Interface to the GAMA Simulation Platform
#'
#' An R Interface to the GAMA Simulation Platform.
#'
#' @docType package
#' @name gamar
NULL
