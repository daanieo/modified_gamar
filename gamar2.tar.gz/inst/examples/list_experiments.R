gaml_file <- system.file("models", "sir.gaml", package = "gamar")
list_experiments(gaml_file)
