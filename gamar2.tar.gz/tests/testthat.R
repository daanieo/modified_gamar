library(testthat)
library(gamar)

test_check("gamar")
