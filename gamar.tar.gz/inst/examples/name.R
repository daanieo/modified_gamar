exp1 <- load_experiment("sir",
                        system.file("models", "sir.gaml", package = "gamar"))
name(exp1)
